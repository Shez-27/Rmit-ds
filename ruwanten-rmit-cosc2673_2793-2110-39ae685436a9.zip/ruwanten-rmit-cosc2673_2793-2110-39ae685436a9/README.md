# RMIT COSC2673/2793 Machine Learning #

This repository will contain the starter codes for the labs and assigments of RMIT machine lerning course COSC 2673/2793

Contact: ruwan.tennakoon@rmit.edu.au


